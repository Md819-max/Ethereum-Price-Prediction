from setuptools import setup, find_packages

setup(
    name="ethereum-price-prediction",
    version="1.0.0",
    author="Mohamed Irfan",
    author_email="your-email@example.com",
    description="A machine learning project to predict Ethereum prices for the next 2 days using multiple ML models.",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/ethereum-price-prediction",
    packages=find_packages(),
    install_requires=[
        "pandas>=1.3.0",
        "numpy>=1.21.0",
        "yfinance>=0.2.12",
        "matplotlib>=3.4.3",
        "scikit-learn>=1.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
